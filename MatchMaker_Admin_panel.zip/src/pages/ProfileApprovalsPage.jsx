export function ProfileApprovalsPage() {
  return (
    <div className="h-full overflow-y-auto px-4 pb-4"><div className="max-w-6xl mx-auto">
    {/* Page Header */}
    <div className="flex justify-between items-end mb-8">
      <div>
        <h2 className="text-3xl font-bold text-white tracking-tight">Profile Approvals Queue</h2>
        <p className="text-on-surface-variant mt-1">Reviewing high-tier membership applications (7 pending)</p>
      </div>
      <div className="flex space-x-2">
        <span className="px-3 py-1 bg-surface-container-high rounded text-xs font-bold uppercase tracking-wider text-primary border border-primary/20">Pending: 07</span>
        <span className="px-3 py-1 bg-surface-container rounded text-xs font-bold uppercase tracking-wider text-[#A3A3A3]">Processed: 142</span>
      </div>
    </div>
    {/* Approvals Queue List */}
    <div className="space-y-8">
      {/* Large Approval Card 1 */}
      <div className="bg-surface-container rounded-xl overflow-hidden shadow-2xl transition-all hover:translate-y-[-2px]">
        <div className="flex flex-col lg:flex-row">
          {/* Left Side: Main Photo */}
          <div className="lg:w-1/3 relative h-96 lg:h-auto overflow-hidden">
            <img className="w-full h-full object-cover" data-alt="professional portrait of a young woman with dark hair and elegant attire in a sophisticated interior setting with soft warm light" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAZV9Pffy9jil0W8NeckikI7_JCTIqh2Lg5Xv0prkVEVrEia52AGwK3KmY1HmaMrUrFkvFfblA-Fz0WWpK5B5NH-eZgGPWbZg3GUtUaWwJ73JqHJGKZcGNh6UAlI3HAF9YABLrvLlOnF1EqKa82JfUkLLq5uOML145OZiJzGg2C6pb5tSAFh_pszVdsbnnX07L5Dfe9ZRyX5C0i7tQBYzdbJTKR_mMNi4J6UqL4MAnZjy-T7yNqPjjH_HMYchx5hJ2WZsHh7tkEZ9g" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-6">
              <span className="text-primary font-bold text-xl">Sarah L.</span>
              <div className="flex items-center text-on-surface-variant text-xs mt-1">
                <span className="material-symbols-outlined text-xs mr-1" data-icon="schedule">schedule</span>
                Submitted 2h ago
              </div>
            </div>
          </div>
          {/* Right Side: Details */}
          <div className="lg:w-2/3 p-8 flex flex-col">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-2xl font-semibold text-white">Sarah Levington, 28</h3>
                <p className="text-on-surface-variant font-medium">Manhattan, New York</p>
              </div>
              <div className="px-4 py-1.5 bg-primary-container/10 border border-primary/30 rounded-full flex items-center">
                <span className="material-symbols-outlined text-primary text-sm mr-2" data-icon="workspace_premium" data-weight="fill">workspace_premium</span>
                <span className="text-primary font-bold text-xs uppercase tracking-widest">Modern Orthodox</span>
              </div>
            </div>
            {/* Photo Verification */}
            <div className="mb-6">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#A3A3A3] mb-3">Verification Assets (4)</h4>
              <div className="grid grid-cols-4 gap-3">
                <div className="aspect-square rounded-lg overflow-hidden border border-outline-variant/20 group cursor-pointer">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform" data-alt="candid close-up of a smiling young woman outdoors at sunset" src="https://lh3.googleusercontent.com/aida-public/AB6AXuASlWTsDmgPz08lf32RRuagCHeKvkHxDGnRtlhuXI4Nk9kbJb3LQFYnYjC83LvDHLXkO6pxCTm8-15eNMcv8u53Xby5L-GPKef40J7JbLv2SqtOu084UOaaSZOBZAC5_reG33a7PWZWHNdybqx8jWXV9Z855rSkxuxIrh3weicAZg_Y62khkSz6CKs_G3792U2JdLGJYsC54CNNq8Nf5PufWDn7Z6egruDxyVKq3xlRoEhqKmg58utSsTNqK8EnbSioVYiOIta9UgI" />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden border border-outline-variant/20 group cursor-pointer">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform" data-alt="medium shot of an elegant woman sitting in a library with soft evening light" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA7nehSlt0lyp5cfme9dO1kTlHcXh6U0AqHA4u0_m-jTLaLaBp_GiRa5CxcAAiKItciKgQJKMt0zarKt5QivgU9BaT2zyn8QVsUSovkdJUErB3xpe9Wtnw2A6EQf6X3QIBPrElaYdBg7D3D_P_ApKVeEGEG1xj1zU_HN8L_9Nd1CjyT66JIZC_9SY9umoGGCBFobj_-bzWbgo-DqIweEqdmsLBIVQ_Rih4Vum3HVDf5sP-XyPaNXD8fr7BfZb-jnwr9-euPDNmwzp0" />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden border border-outline-variant/20 group cursor-pointer">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform" data-alt="close up face shot of a woman with natural makeup in bright daylight" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA4blcqmPAIZVSuEx3xs9ey5kK2kIlrlTWtBY8niJWyYdanNN3B_Ibf_SzbA5mKqAvnpzFy4wtR8aeXVk6365x65Yj1x8nleNu4C3yQ8t8eP0lNo-OZ7mM3Q9mwvKYpEUxDN8EfGUxFXe5oAums7YC6cYqt_xszb5f8oauko40HR4hwbixnhuYwqux5-cPoZK7XsCJJA7luqk5MJjO15H_SW5YSa6KZ4MRJ5LKSEYQV8OW_lgyPRaVhM-n4mLSvAQw4iGhSfbI35Ww" />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden bg-surface-container-high flex items-center justify-center border border-outline-variant/20 cursor-pointer">
                  <span className="material-symbols-outlined text-on-surface-variant">add_circle</span>
                </div>
              </div>
            </div>
            {/* Collapsible Summary */}
            <details className="group border-t border-[#504533]/20 pt-4 mb-8">
              <summary className="flex items-center justify-between cursor-pointer list-none text-sm font-semibold text-primary">
                <span>Profile Summary &amp; Intent</span>
                <span className="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
              </summary>
              <div className="pt-4 text-on-surface-variant text-sm leading-relaxed space-y-3">
                <p>"I'm looking for someone who values tradition but embraces a modern lifestyle. I work in Art Curation and love traveling to Europe during the summers. Family is everything to me."</p>
                <div className="grid grid-cols-2 gap-4 bg-surface-container-low p-4 rounded-lg">
                  <div>
                    <span className="block text-[10px] uppercase tracking-tighter text-[#A3A3A3]">Education</span>
                    <span className="text-white">Masters in Fine Arts, NYU</span>
                  </div>
                  <div>
                    <span className="block text-[10px] uppercase tracking-tighter text-[#A3A3A3]">Occupation</span>
                    <span className="text-white">Senior Curator</span>
                  </div>
                </div>
              </div>
            </details>
            {/* Actions */}
            <div className="mt-auto flex items-center space-x-4 pt-4 border-t border-[#504533]/10">
              <button className="flex-1 metallic-gold text-on-primary py-3 rounded-lg font-bold text-sm hover:opacity-90 transition-all flex items-center justify-center">
                <span className="material-symbols-outlined mr-2" data-icon="check_circle">check_circle</span>
                Approve Profile
              </button>
              <button className="px-6 py-3 border border-error/30 text-error rounded-lg font-bold text-sm hover:bg-error/5 transition-all flex items-center justify-center">
                <span className="material-symbols-outlined mr-2" data-icon="cancel">cancel</span>
                Reject
              </button>
              <button className="px-6 py-3 border border-outline/30 text-on-surface-variant rounded-lg font-bold text-sm hover:bg-white/5 transition-all">
                Request Changes
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Large Approval Card 2 */}
      <div className="bg-surface-container rounded-xl overflow-hidden shadow-2xl transition-all hover:translate-y-[-2px]">
        <div className="flex flex-col lg:flex-row">
          {/* Left Side: Main Photo */}
          <div className="lg:w-1/3 relative h-96 lg:h-auto overflow-hidden">
            <img className="w-full h-full object-cover" data-alt="waist-up portrait of a professional man in a tailored charcoal suit standing in a modern office with city views" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCmcXM84Iu4onIsw4MLBi7siptU5hm9aGeP_GhFIelKHX-fGLEpuIBMC7iXVrxH-xkZjuwt48iPtqoVi66HcER-PRD0HVJZ-ue2y4h4PYjEapi3KdsYEDn9i723xbJaJsKFj7gd0D9sRzk3r0qN_QuGjGBP0NgHAMQ5jbSM688lG8YCgi1ytKwrrqkO5X5s4VEfj6h2dQxmrcrLi4IxlUZUOOUoadwCvOp9LPOiHsDZhsZg9Cy1n_MXgfYNP5LUCv4pDIZXOtKw84w" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-6">
              <span className="text-primary font-bold text-xl">David K.</span>
              <div className="flex items-center text-on-surface-variant text-xs mt-1">
                <span className="material-symbols-outlined text-xs mr-1" data-icon="schedule">schedule</span>
                Submitted 5h ago
              </div>
            </div>
          </div>
          {/* Right Side: Details */}
          <div className="lg:w-2/3 p-8 flex flex-col">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-2xl font-semibold text-white">David Kaplan, 32</h3>
                <p className="text-on-surface-variant font-medium">Tel Aviv, Israel</p>
              </div>
              <div className="px-4 py-1.5 bg-primary-container/10 border border-primary/30 rounded-full flex items-center">
                <span className="material-symbols-outlined text-primary text-sm mr-2" data-icon="workspace_premium" data-weight="fill">workspace_premium</span>
                <span className="text-primary font-bold text-xs uppercase tracking-widest">Shomer Shabbat</span>
              </div>
            </div>
            {/* Photo Verification */}
            <div className="mb-6">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#A3A3A3] mb-3">Verification Assets (3)</h4>
              <div className="grid grid-cols-4 gap-3">
                <div className="aspect-square rounded-lg overflow-hidden border border-outline-variant/20 group cursor-pointer">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform" data-alt="candid profile photo of a man laughing during a formal dinner event" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDA0nOSiU88aHJePU4dD2trLlK3xm-3FRC0BY-xedwk6aLVD0Ic8rHYwXoSRPv63vDSVqaUop11eQphnDuDGlOwmErBfEKVMUIpRywYQdQUZI-bV880rZ0mYdSyhLlC3f2CzgtH3-ahKSelJFYCqKuF-zfuvoLOkBtMsNHIr2Tre18O9yYerG1r9AGgu42BZ5GGLEcKLpKRNqyugLV35AntK3D1nYTP8fKhI9C8NeQWVteY12mMzTXW0wcDWuPTSf729kG47Kkx0eU" />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden border border-outline-variant/20 group cursor-pointer">
                  <img className="w-full h-full object-cover group-hover:scale-110 transition-transform" data-alt="man in business casual attire leaning against a brick wall with soft focus city background" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAV2oI01e3qrOM9n2eyeSb1fwvIGuJnJ0sXk0xsDL9wOcq2CLGIvTZ90h2mAL7y5cKwZXDR38ssW-H7XAjgk7zLHGqLprvMFSTfb3orheQYCrzw2-3WIpZ0ynjNXx8h86G4FFzhMit4_7XgxHZ5YTo344-tl6j0vd7B3TgSuc5SfcPk87llRlaWtQ8Yq7NbyHdb8kB7bhcQHfDALQhzAAvMoFEF6zIjifDZF3Phnx3AGKiaEvmC3AECO5SvPRqTfoQTXgltrg5UvZ8" />
                </div>
                <div className="aspect-square rounded-lg overflow-hidden bg-surface-container-high flex items-center justify-center border border-outline-variant/20 cursor-pointer">
                  <span className="material-symbols-outlined text-on-surface-variant">add_circle</span>
                </div>
              </div>
            </div>
            {/* Collapsible Summary */}
            <details className="group border-t border-[#504533]/20 pt-4 mb-8">
              <summary className="flex items-center justify-between cursor-pointer list-none text-sm font-semibold text-primary">
                <span>Profile Summary &amp; Intent</span>
                <span className="material-symbols-outlined transition-transform group-open:rotate-180">expand_more</span>
              </summary>
              <div className="pt-4 text-on-surface-variant text-sm leading-relaxed space-y-3">
                <p>"Entrepreneur in the tech space. I balance my fast-paced career with dedicated learning and community involvement. Looking for a partner who is intellectually curious and shares my Zionist values."</p>
                <div className="grid grid-cols-2 gap-4 bg-surface-container-low p-4 rounded-lg">
                  <div>
                    <span className="block text-[10px] uppercase tracking-tighter text-[#A3A3A3]">Education</span>
                    <span className="text-white">MBA, Stanford</span>
                  </div>
                  <div>
                    <span className="block text-[10px] uppercase tracking-tighter text-[#A3A3A3]">Occupation</span>
                    <span className="text-white">Venture Capitalist</span>
                  </div>
                </div>
              </div>
            </details>
            {/* Actions */}
            <div className="mt-auto flex items-center space-x-4 pt-4 border-t border-[#504533]/10">
              <button className="flex-1 metallic-gold text-on-primary py-3 rounded-lg font-bold text-sm hover:opacity-90 transition-all flex items-center justify-center">
                <span className="material-symbols-outlined mr-2" data-icon="check_circle">check_circle</span>
                Approve Profile
              </button>
              <button className="px-6 py-3 border border-error/30 text-error rounded-lg font-bold text-sm hover:bg-error/5 transition-all flex items-center justify-center">
                <span className="material-symbols-outlined mr-2" data-icon="cancel">cancel</span>
                Reject
              </button>
              <button className="px-6 py-3 border border-outline/30 text-on-surface-variant rounded-lg font-bold text-sm hover:bg-white/5 transition-all">
                Request Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Pagination/Footer */}
    <div className="mt-12 flex justify-center pb-12">
      <div className="flex items-center space-x-1 bg-surface-container rounded-lg p-1">
        <button className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:text-white transition-colors">
          <span className="material-symbols-outlined">chevron_left</span>
        </button>
        <button className="w-10 h-10 flex items-center justify-center bg-primary-container text-on-primary font-bold rounded">1</button>
        <button className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:text-white transition-colors">2</button>
        <button className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:text-white transition-colors">3</button>
        <button className="w-10 h-10 flex items-center justify-center text-on-surface-variant hover:text-white transition-colors">
          <span className="material-symbols-outlined">chevron_right</span>
        </button>
      </div>
    </div>
  </div></div>

  )
}
