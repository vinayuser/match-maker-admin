export function DashboardPage() {
  return (
    <div className="h-full overflow-y-auto px-4 pb-4">{/* Header Section */}
  <header className="mb-10 flex justify-between items-end">
    <div>
      <h2 className="text-3xl font-extrabold text-white tracking-tight">Dashboard Overview</h2>
      <p className="text-on-surface-variant text-sm mt-1">Platform management and high-level health metrics.</p>
    </div>
    <div className="flex gap-3">
      <button className="px-4 py-2 border border-outline-variant/30 rounded text-xs font-bold uppercase tracking-widest text-[#A3A3A3] hover:border-primary-container/50 hover:text-white transition-all">
        Export Report
      </button>
      <button className="px-4 py-2 metallic-gold rounded text-xs font-bold uppercase tracking-widest text-on-primary shadow-lg shadow-primary-container/20">
        Live View
      </button>
    </div>
  </header>
  {/* Top Stats Row (4 Cards) */}
  <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
    <div className="bg-surface-container rounded-2xl p-6 border-l-4 border-primary-container flex justify-between items-start">
      <div>
        <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-1">Total Registered Users</p>
        <p className="text-3xl font-black text-white tracking-tighter">1,482</p>
        <p className="text-[10px] text-[#A3A3A3] mt-2 flex items-center gap-1">
          <span className="text-green-500 font-bold">+12%</span> vs last month
        </p>
      </div>
      <div className="w-10 h-10 rounded-full bg-primary-container/10 flex items-center justify-center text-primary-container">
        <span className="material-symbols-outlined" data-icon="person">person</span>
      </div>
    </div>
    <div className="bg-surface-container rounded-2xl p-6 flex justify-between items-start">
      <div>
        <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-1">Pending Profile Approvals</p>
        <div className="flex items-center gap-3">
          <p className="text-3xl font-black text-white tracking-tighter">24</p>
          <span className="bg-error/20 text-error px-2 py-0.5 rounded-full text-[10px] font-black animate-pulse">ACTION REQ.</span>
        </div>
        <p className="text-[10px] text-[#A3A3A3] mt-2">Oldest request: 14h ago</p>
      </div>
      <div className="w-10 h-10 rounded-full bg-error-container/20 flex items-center justify-center text-error">
        <span className="material-symbols-outlined" data-icon="hourglass_empty">hourglass_empty</span>
      </div>
    </div>
    <div className="bg-surface-container rounded-2xl p-6 flex justify-between items-start">
      <div>
        <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-1">Active Matches in Progress</p>
        <p className="text-3xl font-black text-white tracking-tighter">86</p>
        <p className="text-[10px] text-[#A3A3A3] mt-2">14 scheduled for first meet</p>
      </div>
      <div className="w-10 h-10 rounded-full bg-tertiary-container/10 flex items-center justify-center text-tertiary-container">
        <span className="material-symbols-outlined" data-icon="favorite">favorite</span>
      </div>
    </div>
    <div className="bg-surface-container rounded-2xl p-6 flex justify-between items-start">
      <div>
        <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-1">Revenue This Month</p>
        <p className="text-3xl font-black text-white tracking-tighter">$42,900</p>
        <p className="text-[10px] text-[#A3A3A3] mt-2 flex items-center gap-1">
          <span className="text-green-500 font-bold">+8.4%</span> Target: $50k
        </p>
      </div>
      <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center text-green-500">
        <span className="material-symbols-outlined" data-icon="payments">payments</span>
      </div>
    </div>
  </section>
  {/* Middle Section - Two Column Layout */}
  <section className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
    {/* Left Card: Recent User Registrations */}
    <div className="bg-surface rounded-2xl shadow-xl overflow-hidden border border-outline-variant/10">
      <div className="px-6 py-4 border-b border-outline-variant/10 bg-surface-container/30 flex justify-between items-center">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Recent User Registrations</h3>
        <button className="text-[10px] font-black text-primary-container hover:underline">VIEW ALL</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-surface-container-low/50">
            <tr>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Name</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Date</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-center">Religious Level</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-outline-variant/5">
            <tr className="hover:bg-surface-container-low transition-colors group">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center text-[10px] font-bold text-primary-container">AZ</div>
                  <div className="text-xs font-semibold text-white">Abraham Zeligman</div>
                </div>
              </td>
              <td className="px-6 py-4 text-xs text-[#A3A3A3]">Oct 24, 2023</td>
              <td className="px-6 py-4 text-center">
                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-tighter bg-outline-variant/20 text-on-surface-variant">Orthodox</span>
              </td>
              <td className="px-6 py-4 text-right">
                <button className="text-[10px] font-black text-primary-container opacity-0 group-hover:opacity-100 transition-opacity">APPROVE</button>
              </td>
            </tr>
            <tr className="hover:bg-surface-container-low transition-colors group">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <img className="w-8 h-8 rounded-full object-cover" data-alt="professional portrait of a young woman with a warm smile, natural light" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAozByfukEYkvT5CfU6OQUOvFZJgbkk1hycEX0UoxfnN_ev_bkLW4qPZBpSC76yDaGpuw8-fArAqfmISscewImFsKVp2IEri40jAjDsyCR4O7cJxF3xq55BeM0HmNM5IxlPCGti5YuedXGTKhjYKtXlDl5APOhrz_FcUzUwqYpFjfBaUIInPjyyPycNgPoVy_6SEdNFKp2Ly1yQDRHXXMkcJsQzxYARpsegLdjt8pGX2ZazT4ZZp4UKO4yJCFvLi_MHmMFupxEObhw" />
                  <div className="text-xs font-semibold text-white">Sarah Shapiro</div>
                </div>
              </td>
              <td className="px-6 py-4 text-xs text-[#A3A3A3]">Oct 24, 2023</td>
              <td className="px-6 py-4 text-center">
                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-tighter bg-outline-variant/20 text-on-surface-variant">Conservative</span>
              </td>
              <td className="px-6 py-4 text-right">
                <button className="text-[10px] font-black text-primary-container opacity-0 group-hover:opacity-100 transition-opacity">APPROVE</button>
              </td>
            </tr>
            <tr className="hover:bg-surface-container-low transition-colors group">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center text-[10px] font-bold text-primary-container">MK</div>
                  <div className="text-xs font-semibold text-white">Mordechai Katz</div>
                </div>
              </td>
              <td className="px-6 py-4 text-xs text-[#A3A3A3]">Oct 23, 2023</td>
              <td className="px-6 py-4 text-center">
                <span className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-tighter bg-outline-variant/20 text-on-surface-variant">Modern Ortho</span>
              </td>
              <td className="px-6 py-4 text-right">
                <button className="text-[10px] font-black text-primary-container opacity-0 group-hover:opacity-100 transition-opacity">APPROVE</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    {/* Right Card: Matchmaker Performance */}
    <div className="bg-surface rounded-2xl shadow-xl overflow-hidden border border-outline-variant/10">
      <div className="px-6 py-4 border-b border-outline-variant/10 bg-surface-container/30 flex justify-between items-center">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Matchmaker Performance</h3>
        <div className="flex gap-2">
          <button className="w-6 h-6 rounded bg-surface-container-highest flex items-center justify-center text-[#A3A3A3]"><span className="material-symbols-outlined text-xs" data-icon="filter_list">filter_list</span></button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-surface-container-low/50">
            <tr>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Name</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-center">Active Cases</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-center">Success Rate</th>
              <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest text-right">Completed</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-outline-variant/5">
            <tr className="hover:bg-surface-container-low transition-colors">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <img className="w-8 h-8 rounded-full object-cover" data-alt="portrait of a professional mature woman with glasses and an elegant outfit" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxCNV6-nDRWaULaOOGAtXbkMR-anXtvxdKFxEM6rHX8iIRdt5hThllf-rkGGdyy6m6IiQWAgVC56DeJFl3FV0vLI2ifD8bX2TffG59cvsXNbp6PdSrie2ZO8ab4KTxpDsnPy_JtYOH4ccDQi-ZD8TeouATHRrdxV1SG1SsTzSQufHk9Y107KTNNC4otvdnXdLrWJOadqWE4Us3PLVdsYSZkHEazXrDVkxpWDsr9nsTssgn9DZVrBOR1cFRfwNk15Gv7KU05WPLinc" />
                  <div className="text-xs font-semibold text-white">Miriam Lefkovits</div>
                </div>
              </td>
              <td className="px-6 py-4 text-center text-xs text-white">12</td>
              <td className="px-6 py-4 text-center">
                <div className="flex flex-col items-center gap-1">
                  <span className="text-xs font-bold text-primary-container">74%</span>
                  <div className="w-12 h-1 bg-surface-container-highest rounded-full overflow-hidden">
                    <div className="h-full bg-primary-container" style={{width: '74%'}} />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 text-right text-xs text-[#A3A3A3]">312</td>
            </tr>
            <tr className="hover:bg-surface-container-low transition-colors">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <img className="w-8 h-8 rounded-full object-cover" data-alt="professional portrait of a man with a friendly demeanor in an office environment" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDjRjpgmarj-UKRAQzP4LQwJ4PXZ-wTYI11OPIB293ls1WlVr61qxrM2BcU1J1zBeM_5IC26LswPu1x5SsQxCqQ37brbrslKvgZi-Yq5xsCWn7gPB7jwB1eOZIBsUmuKKbP_msGAYfMpDt3hLtXPD3C3AK_IUBKGJQCDRCgs0kYUaVxJlxgwZgM1sjo1eM5JPuRtR1dCcT8LDnCvmCU8UP8gSTaev-aMx7Sr7eiKd-ieHhT2crheckb8x3XCHsm5wFsyu5fEfzxJQo" />
                  <div className="text-xs font-semibold text-white">Rabbi Goldberg</div>
                </div>
              </td>
              <td className="px-6 py-4 text-center text-xs text-white">18</td>
              <td className="px-6 py-4 text-center">
                <div className="flex flex-col items-center gap-1">
                  <span className="text-xs font-bold text-primary-container">62%</span>
                  <div className="w-12 h-1 bg-surface-container-highest rounded-full overflow-hidden">
                    <div className="h-full bg-primary-container" style={{width: '62%'}} />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 text-right text-xs text-[#A3A3A3]">456</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>
  {/* Bottom Card: Pending Approvals Queue */}
  <section className="mb-10">
    <div className="bg-[#131313] border-2 border-primary-container/40 rounded-2xl p-8 shadow-[0_0_50px_rgba(245,180,26,0.05)]">
      <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="material-symbols-outlined text-primary-container" data-icon="priority_high" style={{fontVariationSettings: '"FILL" 1'}}>priority_high</span>
            <h3 className="text-lg font-black text-white uppercase tracking-tighter">Critical Pending Approvals Queue</h3>
          </div>
          <p className="text-on-surface-variant text-xs">The following profiles have been waiting for verification for over 24 hours. Immediate action is recommended to maintain concierge SLA.</p>
        </div>
        <button className="bg-primary-container text-on-primary px-6 py-3 rounded font-black text-xs uppercase tracking-widest hover:brightness-110 transition-all shadow-xl shadow-primary-container/20">
          Launch Batch Approval
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Queue Card 1 */}
        <div className="bg-surface-container p-4 rounded-xl flex gap-4 items-center group hover:bg-surface-container-highest transition-all border border-outline-variant/10">
          <img className="w-14 h-14 rounded-full object-cover" data-alt="elegant portrait of a woman in high fashion style with artistic lighting" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBpACeUcr-BeuA0HxAW8suobrpOSTt0wUwUnN-Lz8wlVaVSwej4t0DZ_CZC5FqLlfj4hcyqOp4-Zz4muHPy1ldcHJIYyvL1XYzCG3LindOf-JAHwOZezVsxzI2PU8RzyUvDxZLxsx-9hqTad5jGmquO1--W58MrY0ijGm0IN1bOic2Ge5Jzxr_xoMKRBakXDi2vEJE3VTqqqkHHfR1EqyotOaeCUN-jIjBAj5Km6XSpVB3KRK1U9ICW1MsHwp9ptHGXQIscS_n8Bw4" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white truncate">Rachel Weissman</p>
            <p className="text-[10px] text-on-surface-variant/70 uppercase font-semibold">Premium Member</p>
            <div className="mt-2 flex gap-1">
              <span className="text-[9px] bg-error-container/20 text-error px-1.5 py-0.5 rounded font-bold uppercase">32 Hours</span>
              <span className="text-[9px] bg-surface-container-highest text-white px-1.5 py-0.5 rounded font-bold uppercase">Profile Check</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#A3A3A3] group-hover:text-primary-container cursor-pointer transition-colors" data-icon="chevron_right">chevron_right</span>
        </div>
        {/* Queue Card 2 */}
        <div className="bg-surface-container p-4 rounded-xl flex gap-4 items-center group hover:bg-surface-container-highest transition-all border border-outline-variant/10">
          <div className="w-14 h-14 rounded-full bg-surface-container-highest flex items-center justify-center text-xl font-black text-primary-container">YK</div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white truncate">Yosef Klein</p>
            <p className="text-[10px] text-on-surface-variant/70 uppercase font-semibold">Gold Tier</p>
            <div className="mt-2 flex gap-1">
              <span className="text-[9px] bg-error-container/20 text-error px-1.5 py-0.5 rounded font-bold uppercase">28 Hours</span>
              <span className="text-[9px] bg-surface-container-highest text-white px-1.5 py-0.5 rounded font-bold uppercase">Identity Doc</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#A3A3A3] group-hover:text-primary-container cursor-pointer transition-colors" data-icon="chevron_right">chevron_right</span>
        </div>
        {/* Queue Card 3 */}
        <div className="bg-surface-container p-4 rounded-xl flex gap-4 items-center group hover:bg-surface-container-highest transition-all border border-outline-variant/10">
          <img className="w-14 h-14 rounded-full object-cover" data-alt="professional corporate headshot of a smiling man with clean styling and soft lighting" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBTqP9OegSX12Hfp6HF-qTkfDmhrZa39OtKflEH7g8DtbpYGTHXooevzd-L3ALzGurS_qunpHnALUecB_3T8BLGv0hnTwweu0WzvkCEBUa75-WzW8QAGKxdS33XNzTSD-baACphcJUUPA6i6a2X_D_4cBhzutUMWiAPRxk5knhQiej4k022iqg6PItPON0k85iOLbnp-z6ZwLbhagB81erGxWevbrfRhv9JGfmrMNq34S8IdSbIwO03HOVKCzEOfz6ozhK_LOL6eYA" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white truncate">David Stein</p>
            <p className="text-[10px] text-on-surface-variant/70 uppercase font-semibold">Matchmaker Ref</p>
            <div className="mt-2 flex gap-1">
              <span className="text-[9px] bg-error-container/20 text-error px-1.5 py-0.5 rounded font-bold uppercase">26 Hours</span>
              <span className="text-[9px] bg-surface-container-highest text-white px-1.5 py-0.5 rounded font-bold uppercase">Reference Check</span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#A3A3A3] group-hover:text-primary-container cursor-pointer transition-colors" data-icon="chevron_right">chevron_right</span>
        </div>
      </div>
    </div>
  </section></div>

  )
}
