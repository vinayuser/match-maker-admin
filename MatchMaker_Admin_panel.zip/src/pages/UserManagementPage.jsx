export function UserManagementPage() {
  return (
    <div className="h-full overflow-y-auto px-4 pb-4"><div className="p-8 max-w-[1600px] mx-auto">
    {/* Header Section */}
    <div className="flex justify-between items-end mb-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-white">User Management</h1>
        <p className="text-on-surface-variant text-sm mt-1">Review, manage, and verify premium member credentials.</p>
      </div>
      <div className="flex gap-3">
        <button className="px-5 py-2.5 bg-surface-container hover:bg-surface-container-high text-white text-xs font-bold uppercase tracking-widest rounded-sm transition-colors border border-outline-variant/10">
          Export Directory
        </button>
        <button className="px-5 py-2.5 gold-metallic-cta text-on-primary text-xs font-bold uppercase tracking-widest rounded-sm">
          Add New Member
        </button>
      </div>
    </div>
    {/* Filter Bar */}
    <div className="bg-surface border border-outline-variant/10 rounded-sm p-4 mb-6 flex flex-wrap items-center gap-6 shadow-xl">
      <div className="flex-1 min-w-[300px] relative">
        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-lg">search</span>
        <input className="w-full bg-surface-container-lowest border-none text-sm py-2.5 pl-10 pr-4 text-white placeholder:text-on-surface-variant/50 focus:ring-1 focus:ring-primary-container rounded-sm" placeholder="Search by name, email or member ID..." type="text" />
      </div>
      <div className="flex items-center gap-4">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] uppercase tracking-widest text-on-surface-variant font-bold">Status</label>
          <select className="bg-surface-container-lowest border-none text-xs text-white py-2 pl-3 pr-8 focus:ring-1 focus:ring-primary-container rounded-sm appearance-none cursor-pointer min-w-[120px]">
            <option>All Statuses</option>
            <option>Active</option>
            <option>Paused</option>
            <option>Locked</option>
            <option>Closed</option>
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] uppercase tracking-widest text-on-surface-variant font-bold">Religious Level</label>
          <select className="bg-surface-container-lowest border-none text-xs text-white py-2 pl-3 pr-8 focus:ring-1 focus:ring-primary-container rounded-sm appearance-none cursor-pointer min-w-[140px]">
            <option>All Levels</option>
            <option>Ultra-Orthodox</option>
            <option>Modern Orthodox</option>
            <option>Traditional</option>
            <option>Liberal</option>
          </select>
        </div>
        <button className="mt-4 flex items-center gap-2 text-on-surface-variant hover:text-white text-xs font-bold transition-colors uppercase tracking-widest">
          <span className="material-symbols-outlined text-sm">tune</span>
          More Filters
        </button>
      </div>
    </div>
    {/* Data Table */}
    <div className="bg-[#1A1A1A] rounded-sm overflow-hidden border border-outline-variant/10 shadow-2xl">
      <table className="w-full text-left border-collapse">
        <thead className="bg-surface-container-low border-b border-outline-variant/10">
          <tr>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Profile</th>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Contact Details</th>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Religious Level</th>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Status</th>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Verification</th>
            <th className="px-6 py-4 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-outline-variant/5">
          {/* Row 1 */}
          <tr className="hover:bg-surface-container-low/50 transition-colors group">
            <td className="px-6 py-4">
              <div className="flex items-center gap-4">
                <img alt="User" className="w-10 h-10 rounded-sm object-cover" data-alt="elegant portrait of a young woman with refined features and sophisticated lighting" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD5EWYnNzxRtEZu0CqOmr7nRkXlTNOe2d9wr7y-LdEZHnETbXYLV31Cgms5FP5in0-HxFYMNWiqu0scXfotgeIK1LL1P8CCPR-r9gJSPiOR_u_CezKE71FOuaf5LeoQgEqEGxZwNh0qfXnmsp6pnAyt0Q7pcgpQNyKdbtB2Gu3VLKTd4wVd3R3K_bubf1aF0APSRNE_zMMVZdiHVg_f_uVJugKc4UvBbQdb6zNGskZIM4afeDaVhPUEFrtSRiOqUoh8-UjpcslxBFM" />
                <div>
                  <div className="text-sm font-bold text-white">Rebecca Silverstein</div>
                  <div className="text-[10px] text-on-surface-variant">ID: #KSH-9921</div>
                </div>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="text-xs text-white">reb****@domain.com</div>
              <div className="text-xs text-on-surface-variant mt-0.5">+1 (555) ••• ••88</div>
            </td>
            <td className="px-6 py-4">
              <span className="px-2.5 py-1 rounded-full bg-primary-container/10 text-primary-container text-[10px] font-bold uppercase tracking-wider border border-primary-container/20">Modern Orthodox</span>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                <span className="text-xs text-white">Active</span>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-1.5 text-primary-fixed-dim">
                <span className="material-symbols-outlined text-sm" style={{fontVariationSettings: '"FILL" 1'}}>verified</span>
                <span className="text-[10px] font-bold uppercase tracking-widest">Verified</span>
              </div>
            </td>
            <td className="px-6 py-4 text-right">
              <div className="flex justify-end gap-2">
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">visibility</span></button>
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">edit</span></button>
                <button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-sm transition-all"><span className="material-symbols-outlined text-lg">lock</span></button>
              </div>
            </td>
          </tr>
          {/* Row 2 */}
          <tr className="hover:bg-surface-container-low/50 transition-colors group">
            <td className="px-6 py-4">
              <div className="flex items-center gap-4">
                <img alt="User" className="w-10 h-10 rounded-sm object-cover" data-alt="striking professional portrait of a gentleman in a bespoke suit with classical library background" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCR2sAzywSQrkTB4qLUzbOuTarleUkiYZ9lKIXofAmiX9Tm9c-ey4yfDKo3dnb24JaOtcZ3ly1pGl2FobgXTy7dnq0Gokpm8bIcmK1r431ZfkNKVXalhIJvV9FlkOAXI5KX3tiEezzSFTEcRuELP2K_3boEGvu_bM73Likwlz592-Diq9mPmcwYa-0c2o3AfPjCXawl0GzgDr3jgYB-U5xmQldKVhYexjA7Ad14iR6U3icra_pXB8nOm2YSPgRj6eQ1H216NUju4sw" />
                <div>
                  <div className="text-sm font-bold text-white">Avi Mizrahi</div>
                  <div className="text-[10px] text-on-surface-variant">ID: #KSH-4410</div>
                </div>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="text-xs text-white">avi****@mizrahi.com</div>
              <div className="text-xs text-on-surface-variant mt-0.5">+1 (212) ••• ••12</div>
            </td>
            <td className="px-6 py-4">
              <span className="px-2.5 py-1 rounded-full bg-primary-container/10 text-primary-container text-[10px] font-bold uppercase tracking-wider border border-primary-container/20">Ultra-Orthodox</span>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />
                <span className="text-xs text-white">Paused</span>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-1.5 text-on-surface-variant">
                <span className="material-symbols-outlined text-sm">hourglass_empty</span>
                <span className="text-[10px] font-bold uppercase tracking-widest">Pending</span>
              </div>
            </td>
            <td className="px-6 py-4 text-right">
              <div className="flex justify-end gap-2">
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">visibility</span></button>
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">edit</span></button>
                <button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-sm transition-all"><span className="material-symbols-outlined text-lg">lock</span></button>
              </div>
            </td>
          </tr>
          {/* Row 3 */}
          <tr className="hover:bg-surface-container-low/50 transition-colors group">
            <td className="px-6 py-4">
              <div className="flex items-center gap-4">
                <img alt="User" className="w-10 h-10 rounded-sm object-cover" data-alt="close-up editorial shot of a woman with sophisticated jewelry and soft cinematic lighting" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFiIRX39e8L1pX4Qd6ou3d2V4iVNSX6tdsLwBZapNn-468QdEaMwJ-4wJL-nBNx864LZVyXkNlpxT_sVVWa8UMlLUWstaaEl-LkxSnlGQqFUmZELhqbGLp3OdN00iVSsbqQ6niEOFQ9tbMV424kE5Mbbk0vNhSJpYCVOD2l8rLMMeTgm8gZ1d6bJkeSyyUqtLovOhG5oHN-g-gx7Ia5h_0uQ0KsgQJo31C0cGIWa_1zaSqAPg5R8m-rWiAfYe2Hd6eg1ag6RVKMtE" />
                <div>
                  <div className="text-sm font-bold text-white">Sarah Levin</div>
                  <div className="text-[10px] text-on-surface-variant">ID: #KSH-2290</div>
                </div>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="text-xs text-white">sar****@levin.org</div>
              <div className="text-xs text-on-surface-variant mt-0.5">+44 20 •••• ••91</div>
            </td>
            <td className="px-6 py-4">
              <span className="px-2.5 py-1 rounded-full bg-primary-container/10 text-primary-container text-[10px] font-bold uppercase tracking-wider border border-primary-container/20">Traditional</span>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
                <span className="text-xs text-white">Locked</span>
              </div>
            </td>
            <td className="px-6 py-4">
              <div className="flex items-center gap-1.5 text-error">
                <span className="material-symbols-outlined text-sm">cancel</span>
                <span className="text-[10px] font-bold uppercase tracking-widest">Rejected</span>
              </div>
            </td>
            <td className="px-6 py-4 text-right">
              <div className="flex justify-end gap-2">
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">visibility</span></button>
                <button className="p-2 text-on-surface-variant hover:text-white hover:bg-surface-container-highest rounded-sm transition-all"><span className="material-symbols-outlined text-lg">edit</span></button>
                <button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-sm transition-all"><span className="material-symbols-outlined text-lg">lock_open</span></button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <div className="px-6 py-4 bg-surface-container-low flex justify-between items-center">
        <span className="text-xs text-on-surface-variant font-medium">Showing 1-3 of 842 premium members</span>
        <div className="flex gap-2">
          <button className="px-3 py-1 bg-surface-container text-on-surface-variant rounded-sm text-xs hover:text-white transition-colors border border-outline-variant/10">Previous</button>
          <button className="px-3 py-1 bg-primary-container/10 text-primary-container rounded-sm text-xs font-bold border border-primary-container/20">1</button>
          <button className="px-3 py-1 bg-surface-container text-on-surface-variant rounded-sm text-xs hover:text-white transition-colors border border-outline-variant/10">2</button>
          <button className="px-3 py-1 bg-surface-container text-on-surface-variant rounded-sm text-xs hover:text-white transition-colors border border-outline-variant/10">3</button>
          <button className="px-3 py-1 bg-surface-container text-on-surface-variant rounded-sm text-xs hover:text-white transition-colors border border-outline-variant/10">Next</button>
        </div>
      </div>
    </div>
  </div></div>

  )
}
