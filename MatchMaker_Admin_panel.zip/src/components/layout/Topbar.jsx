import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import { ROUTES } from "../../constants/appConfig"
import { logout } from "../../store/slices/authSlice"

export function Topbar() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { user } = useSelector((state) => state.auth)

  const handleLogout = () => {
    dispatch(logout())
    navigate(ROUTES.login)
  }

  return (
    <header className="h-16 bg-[#131313]/80 backdrop-blur-xl border-b border-outline-variant/20 px-8 flex justify-between items-center">
      <div className="flex items-center gap-8">
        <div className="relative w-72">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-sm">
            search
          </span>
          <input
            className="bg-surface-container-lowest/50 border-none rounded-lg pl-10 pr-4 py-2 text-sm text-on-surface w-full focus:ring-1 focus:ring-primary-container/50 placeholder:text-on-surface-variant/40"
            placeholder="Global search for clients or matches..."
            type="text"
          />
        </div>
        <nav className="hidden md:flex gap-6">
          <span className="text-[#F5B41A] font-bold border-b-2 border-[#F5B41A] pb-1 text-sm">
            Global View
          </span>
          <span className="text-[#A3A3A3] font-medium text-sm">Metrics</span>
          <span className="text-[#A3A3A3] font-medium text-sm">Team Chat</span>
        </nav>
      </div>

      <div className="flex items-center gap-4">
        <p className="text-xs text-on-surface-variant hidden lg:block">
          {user?.name} - {user?.role}
        </p>
        <button
          type="button"
          onClick={handleLogout}
          className="metallic-gradient px-4 py-2 rounded text-on-primary text-xs font-bold uppercase tracking-widest shadow-lg shadow-primary-container/10"
        >
          Logout
        </button>
      </div>
    </header>
  )
}
