export const ROUTES = {
  login: "/login",
  dashboard: "/dashboard",
  userDirectory: "/users/directory",
  userManagement: "/users/management",
  profileApprovals: "/approvals/profile-queue",
  matchmakerDashboard: "/matchmaker/dashboard",
  matchmakerTeam: "/matchmaker/team",
  matchmakerPermissions: "/matchmaker/permissions",
  matchPipeline: "/matches/pipeline",
  matchManagement: "/matches/management",
  caseFileDetail: "/matches/case-file",
  completedMatches: "/matches/completed",
  completedRevenue: "/finance/completed-cycles-revenue",
  systemConfiguration: "/system/configuration"
}

export const STATUS_CODES = {
  ok: 200,
  created: 201,
  badRequest: 400,
  unauthorized: 401,
  forbidden: 403,
  notFound: 404,
  serverError: 500
}

export const APP_MESSAGES = {
  auth: {
    invalidCredentials: "Invalid credentials. Try the dummy credentials shown below.",
    loginSuccess: "Login successful.",
    logoutSuccess: "You have been logged out."
  },
  common: {
    fetchSuccess: "Data loaded successfully.",
    serverUnavailable: "Server unavailable. Using fallback response.",
    unauthorized: "Session expired. Please log in again."
  }
}

export const DUMMY_CREDENTIALS = {
  email: "admin@kesher.com",
  password: "Admin@123"
}

export const NAV_LINKS = [
  { label: "Dashboard", icon: "dashboard", to: ROUTES.dashboard },
  { label: "User Directory", icon: "group", to: ROUTES.userDirectory },
  { label: "User Management", icon: "manage_accounts", to: ROUTES.userManagement },
  { label: "Approval Queue", icon: "fact_check", to: ROUTES.profileApprovals },
  { label: "Matchmaker Dashboard", icon: "insights", to: ROUTES.matchmakerDashboard },
  { label: "Matchmaker Team", icon: "diversity_3", to: ROUTES.matchmakerTeam },
  { label: "Permissions", icon: "admin_panel_settings", to: ROUTES.matchmakerPermissions },
  { label: "Match Pipeline", icon: "account_tree", to: ROUTES.matchPipeline },
  { label: "Match Management", icon: "conversion_path", to: ROUTES.matchManagement },
  { label: "Case File Detail", icon: "description", to: ROUTES.caseFileDetail },
  { label: "Completed Matches", icon: "handshake", to: ROUTES.completedMatches },
  { label: "Revenue Cycles", icon: "payments", to: ROUTES.completedRevenue },
  { label: "System Settings", icon: "settings", to: ROUTES.systemConfiguration }
]

export const NAV_ACTIVE_PATTERNS = {
  [ROUTES.dashboard]: [ROUTES.dashboard],
  [ROUTES.userDirectory]: [ROUTES.userDirectory],
  [ROUTES.userManagement]: [ROUTES.userManagement],
  [ROUTES.profileApprovals]: [ROUTES.profileApprovals],
  [ROUTES.matchmakerDashboard]: [ROUTES.matchmakerDashboard],
  [ROUTES.matchmakerTeam]: [ROUTES.matchmakerTeam],
  [ROUTES.matchmakerPermissions]: [ROUTES.matchmakerPermissions],
  [ROUTES.matchPipeline]: [ROUTES.matchPipeline],
  [ROUTES.matchManagement]: [ROUTES.matchManagement, ROUTES.caseFileDetail],
  [ROUTES.caseFileDetail]: [ROUTES.caseFileDetail, ROUTES.matchManagement],
  [ROUTES.completedMatches]: [ROUTES.completedMatches],
  [ROUTES.completedRevenue]: [ROUTES.completedRevenue],
  [ROUTES.systemConfiguration]: [ROUTES.systemConfiguration]
}
