import { APP_MESSAGES, DUMMY_CREDENTIALS, STATUS_CODES } from "../constants/appConfig"

export const loginWithDummyAuth = async (payload) => {
  const { email, password } = payload

  await new Promise((resolve) => {
    setTimeout(resolve, 500)
  })

  if (email === DUMMY_CREDENTIALS.email && password === DUMMY_CREDENTIALS.password) {
    return {
      status: STATUS_CODES.ok,
      message: APP_MESSAGES.auth.loginSuccess,
      data: {
        token: "dummy-kesher-admin-token",
        user: {
          name: "David Cohen",
          role: "Super Admin",
          email: DUMMY_CREDENTIALS.email
        }
      }
    }
  }

  throw new Error(APP_MESSAGES.auth.invalidCredentials)
}
